import 'dart:io';
import 'package:csv/csv.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path_provider/path_provider.dart';

class CSVUtils {
  static Future<String> getFilePath() async {
    final directory = await getApplicationDocumentsDirectory();
    return '${directory.path}/data.csv';
  }

  static Future<void> saveToLocalCSV(List<List<dynamic>> data) async {
    final filePath = await getFilePath();
    final file = File(filePath);
    final csvData = const ListToCsvConverter().convert(data);
    await file.writeAsString(csvData);
  }

  static Future<List<List<dynamic>>> readFromLocalCSV() async {
    final filePath = await getFilePath();
    final file = File(filePath);
    final csvData = await file.readAsString();
    return const CsvToListConverter().convert(csvData);
  }

  static Future<void> uploadCSVToFirebase() async {
    final filePath = await getFilePath();
    final file = File(filePath);
    final storageRef = FirebaseStorage.instance.ref().child('data.csv');
    await storageRef.putFile(file);
  }
}
