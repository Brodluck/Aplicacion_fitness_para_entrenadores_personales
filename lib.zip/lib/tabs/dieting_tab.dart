import 'package:flutter/material.dart';

class DietingTab extends StatelessWidget {
  const DietingTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Dieting'),
    );
  }
}
