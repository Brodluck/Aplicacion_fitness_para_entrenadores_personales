import 'package:flutter/material.dart';

class TrainerDashboardTab extends StatelessWidget {
  const TrainerDashboardTab({super.key});

  @override
  Widget build(BuildContext context) {
    return const Center(
      child: Text('Trainer Dashboard'),
    );
  }
}
