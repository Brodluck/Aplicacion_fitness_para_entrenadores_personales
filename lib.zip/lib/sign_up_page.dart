// // ignore_for_file: prefer_const_constructors

// import 'package:firebase_auth/firebase_auth.dart';
// import 'package:flutter/material.dart';
// import 'package:intl_phone_field/intl_phone_field.dart';
// import 'package:ventanas/login_page.dart';
// import 'package:ventanas/additional_info_page.dart'; // Add this import

// class SignUpPage extends StatelessWidget {
//   SignUpPage({super.key});

//   final _formKey = GlobalKey<FormState>(); // Form key for validation
//   final TextEditingController _passwordController = TextEditingController();
//   final TextEditingController _confirmPasswordController = TextEditingController();
//   final TextEditingController _emailController = TextEditingController();

//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Center(
//         child: Padding(
//           padding: const EdgeInsets.all(36.0),
//           child: SingleChildScrollView(
//             child: Form(
//               key: _formKey, // Associate the Form with the GlobalKey
//               child: Column(
//                 mainAxisAlignment: MainAxisAlignment.center,
//                 children: <Widget>[
//                   Text(
//                     'Register a new account',
//                     style: Theme.of(context).textTheme.headlineMedium,
//                   ),
//                   const SizedBox(height: 48.0),
//                   TextFormField(
//                     decoration: const InputDecoration(
//                       labelText: 'Full name',
//                       border: OutlineInputBorder(),
//                     ),
//                   ),
//                   const SizedBox(height: 24.0),
//                   TextFormField(
//                     controller: _emailController,
//                     decoration: const InputDecoration(
//                       labelText: 'Email',
//                       border: OutlineInputBorder(),
//                     ),
//                     validator: (value) => _validateEmail(value),
//                     autovalidateMode: AutovalidateMode.onUserInteraction,
//                   ),
//                   const SizedBox(height: 24.0),
//                   const IntlPhoneField(
//                     decoration: InputDecoration(
//                       labelText: 'Phone Number',
//                       border: OutlineInputBorder(),
//                     ),
//                     initialCountryCode: 'ES', // Set the default country code to Spain (+34),
//                   ),
//                   const SizedBox(height: 24.0),
//                   TextFormField(
//                     controller: _passwordController,
//                     obscureText: true,
//                     decoration: const InputDecoration(
//                       labelText: 'Password',
//                       border: OutlineInputBorder(),
//                     ),
//                     validator: (value) => _validatePassword(value),
//                   ),
//                   const SizedBox(height: 24.0),
//                   TextFormField(
//                     controller: _confirmPasswordController,
//                     obscureText: true,
//                     decoration: const InputDecoration(
//                       labelText: 'Confirm Password',
//                       border: OutlineInputBorder(),
//                     ),
//                     validator: (value) {
//                       if (value != _passwordController.text) {
//                         return 'Passwords do not match';
//                       }
//                       return null;
//                     },
//                   ),
//                   const SizedBox(height: 36.0),
//                   ElevatedButton(
//                     onPressed: () async {
//                       if (_formKey.currentState!.validate()) {
//                         await _register();
//                         Navigator.push(
//                           context,
//                           MaterialPageRoute(builder: (context) => AdditionalInfoPage()),
//                         );
//                       }
//                     },
//                     child: const Text('Next'),
//                   ),
//                   TextButton(
//                     onPressed: () {
//                       Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginPage()));
//                     },
//                     child: Text('Already have an account? Login', style: TextStyle(color: Colors.blue.shade200)),
//                   ),
//                 ],
//               ),
//             ),
//           ),
//         ),
//       ),
//     );
//   }

//   Future<void> _register() async {
//     try {
//       final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
//         email: _emailController.text.trim(),
//         password: _passwordController.text.trim(),
//       );
//       // Perform additional actions with the user if necessary
//       print('User registered: ${credential.user?.uid}');
//     } catch (e) {
//       print('Error: $e');
//       // Handle error (e.g., show a Snackbar or dialog)
//     }
//   }

//   String? _validateEmail(String? value) {
//     String pattern = r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$';
//     RegExp regex = RegExp(pattern);
//     if (value == null || !regex.hasMatch(value)) {
//       return 'Enter a valid email address';
//     }
//     return null;
//   }

//   String? _validatePassword(String? value) {
//     String pattern =
//         r'^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*(),.?":{}|<>]).{8,}$';
//     RegExp regex = RegExp(pattern);
//     if (value == null || !regex.hasMatch(value)) {
//       return 'Password must be at least 8 characters long and include an \n ppercase letter, a number, and a special character';
//     }
//     return null;
//   }
// }

// ignore_for_file: prefer_const_constructors

import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:intl_phone_field/intl_phone_field.dart';
import 'package:ventanas/login_page.dart';
import 'package:ventanas/additional_info_page.dart'; // Add this import

class SignUpPage extends StatelessWidget {
  SignUpPage({super.key});

  final _formKey = GlobalKey<FormState>(); // Form key for validation
  final TextEditingController _passwordController = TextEditingController();
  final TextEditingController _confirmPasswordController = TextEditingController();
  final TextEditingController _emailController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(36.0),
          child: SingleChildScrollView(
            child: Form(
              key: _formKey, // Associate the Form with the GlobalKey
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: <Widget>[
                  Text(
                    'Register a new account',
                    style: Theme.of(context).textTheme.headlineMedium,
                  ),
                  const SizedBox(height: 48.0),
                  TextFormField(
                    decoration: const InputDecoration(
                      labelText: 'Full name',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 24.0),
                  TextFormField(
                    controller: _emailController,
                    decoration: const InputDecoration(
                      labelText: 'Email',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) => _validateEmail(value),
                    autovalidateMode: AutovalidateMode.onUserInteraction,
                  ),
                  const SizedBox(height: 24.0),
                  const IntlPhoneField(
                    decoration: InputDecoration(
                      labelText: 'Phone Number',
                      border: OutlineInputBorder(),
                    ),
                    initialCountryCode: 'ES', // Set the default country code to Spain (+34),
                  ),
                  const SizedBox(height: 24.0),
                  TextFormField(
                    controller: _passwordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Password',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) => _validatePassword(value),
                  ),
                  const SizedBox(height: 24.0),
                  TextFormField(
                    controller: _confirmPasswordController,
                    obscureText: true,
                    decoration: const InputDecoration(
                      labelText: 'Confirm Password',
                      border: OutlineInputBorder(),
                    ),
                    validator: (value) {
                      if (value != _passwordController.text) {
                        return 'Passwords do not match';
                      }
                      return null;
                    },
                  ),
                  const SizedBox(height: 36.0),
                  ElevatedButton(
                    onPressed: () async {
                      if (_formKey.currentState!.validate()) {
                        await _register();
                        Navigator.push(
                          context,
                          MaterialPageRoute(builder: (context) => AdditionalInfoPage()),
                        );
                      }
                    },
                    child: const Text('Next'),
                  ),
                  TextButton(
                    onPressed: () {
                      Navigator.pushReplacement(context, MaterialPageRoute(builder: (context) => LoginPage()));
                    },
                    child: Text('Already have an account? Login', style: TextStyle(color: Colors.blue.shade200)),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> _register() async {
    try {
      final credential = await FirebaseAuth.instance.createUserWithEmailAndPassword(
        email: _emailController.text.trim(),
        password: _passwordController.text.trim(),
      );
      // Perform additional actions with the user if necessary
      print('User registered: ${credential.user?.uid}');
    } catch (e) {
      print('Error: $e');
      // Handle error (e.g., show a Snackbar or dialog)
    }
  }

  String? _validateEmail(String? value) {
    String pattern = r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$';
    RegExp regex = RegExp(pattern);
    if (value == null || !regex.hasMatch(value)) {
      return 'Enter a valid email address';
    }
    return null;
  }

  String? _validatePassword(String? value) {
    String pattern =
        r'^(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#$%^&*(),.?":{}|<>]).{8,}$';
    RegExp regex = RegExp(pattern);
    if (value == null || !regex.hasMatch(value)) {
      return 'Password must be at least 8 characters long and include an \n ppercase letter, a number, and a special character';
    }
    return null;
  }
}
